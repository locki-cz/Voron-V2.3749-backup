import{S as r}from"./Viewer-cef512b1.js";const e="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";r.IncludesShadersStore[e]=a;
