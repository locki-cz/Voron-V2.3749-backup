import{S as r}from"./Viewer-cef512b1.js";const e="kernelBlurVaryingDeclaration",a="varying sampleCoord{X}: vec2f;";r.IncludesShadersStoreWGSL[e]=a;
